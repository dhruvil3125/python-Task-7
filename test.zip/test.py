import psycopg2
def table():

    conn = psycopg2.connect(dbname="postgres",user="postgres",password="031205",host="localhost",port="5432")

    curssor = conn.cursor()
    curssor.execute('''create table employees2(Name Text,ID int,Age int);''')
# print("Table created successfully")


    conn.commit()
    conn.close()
    
def data():

    conn = psycopg2.connect(dbname="postgres",user="postgres",password="031205",host="localhost",port="5432")

    name = input('Enter name:')
    id = int(input('Enter Id:'))
    age = int(input('Enter age:'))

    curssor = conn.cursor()
    query = '''insert into employees2(Name,ID,Age) values(%s,%s,%s);'''
    curssor.execute(query,(name,id,age))
    
    print("data added successfully")


    conn.commit()
    conn.close()
data()

# def extract():

#     conn = psycopg2.connect(dbname="postgres",user="postgres",password="031205",host="localhost",port="5432")

#     curssor = conn.cursor()
#     curssor.execute('''select * from employees2;''')
#     print(curssor.fetchone())
#     # show = curssor.fetchone()
#     # print(show[0])

#     conn.commit()
#     conn.close()

# extract()